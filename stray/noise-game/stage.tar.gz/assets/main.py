# /// script
# dependencies = ["numpy", "pygame-ce"]
# ///
import asyncio
import numpy
import pygame

from noise_game.browser import BrowserGame


async def main():
    game = BrowserGame()
    await game.run_browser()


asyncio.run(main())
