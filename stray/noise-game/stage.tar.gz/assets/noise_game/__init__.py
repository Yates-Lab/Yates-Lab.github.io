"""NOISE: a first-person maze game with an independent, deterministic simulation."""

__version__ = "0.1.0"
