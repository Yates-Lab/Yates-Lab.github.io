"""Motion-defined rendering with a stationary, screen-space 1/f appearance.

Geometry supplies correspondence, never intensity. A white Gaussian carrier is
transported with a PARTIAL PERMUTATION: every old sample may be used at most once,
and every output pixel gets exactly one sample or a fresh independent draw.
Consequently, for a fixed scene/camera trajectory, the carrier in every frame is
spatially IID. A single, geometry-independent Fourier filter then supplies the
same 1/f spatial statistics over the entire image. There are no per-surface
textures, interpolation blur, lighting, contrast changes, eyes, or outlines.

Ordinary bilinear warping does not have this property: stretching, duplicated
samples, and differently blurred surfaces can expose structure in a still.
"""

from dataclasses import dataclass
import math

import numpy as np
import pygame


@dataclass
class Scene:
    x: float
    y: float
    angle: float
    horizon: float
    time: float
    depth: np.ndarray
    labels: np.ndarray
    rx: np.ndarray
    ry: np.ndarray
    objects: dict


class MotionRenderer:
    def __init__(self, renderer, seed=71931):
        self.renderer = renderer
        self.width, self.height = renderer.width, renderer.height
        self.projection = renderer.projection
        # Match the raycaster's inclusive linspace exactly, including identity.
        self.projection_x = (self.width - 1) / (2 * math.tan(math.radians(78) / 2))
        self.columns = np.arange(self.width, dtype=np.float32)[None, :]
        self.rows = np.arange(self.height, dtype=np.float32)[:, None]
        self.indices = np.arange(self.width * self.height, dtype=np.int32)
        freq = np.hypot(np.fft.fftfreq(self.height)[:, None],
                        np.fft.rfftfreq(self.width)[None, :])
        freq[0, 0] = 1
        self.filter = (1 / np.sqrt(freq)).astype(np.float32)
        self.filter[0, 0] = 0
        self.seed = int(seed)
        self.surface = pygame.Surface((self.width, self.height))
        self.reset()

    def reset(self):
        self.rng = np.random.default_rng(self.seed)
        self.carrier = self.rng.standard_normal((self.height, self.width), dtype=np.float32)
        self.previous = None
        self.last_key = None
        self.last_source_map = np.full(self.carrier.shape, -1, dtype=np.int32)
        self.last_flow = None
        self.retained_fraction = 0.0
        self._ghost_keys = {}
        self._next_ghost_key = 2
        self.gray = self._pink(self.carrier)

    def _pink(self, carrier):
        spectrum = np.fft.rfft2(carrier) * self.filter
        field = np.fft.irfft2(spectrum, s=carrier.shape, axes=(0, 1))
        field = field * (37.0 / max(float(field.std()), 1e-6)) + 127.5
        return np.clip(field, 0, 255).astype(np.uint8)

    def _ghost_geometry(self, scene, ghost, key):
        dx, dy = ghost.x - scene.x, ghost.y - scene.y
        c, s = math.cos(scene.angle), math.sin(scene.angle)
        depth, lateral = dx * c + dy * s, -dx * s + dy * c
        z = .38 + math.sin(scene.time * 6 + ghost.phase) * .018
        scene.objects[key] = (ghost.x, ghost.y, z, "ghost", ghost.opacity)
        if depth <= .1:
            return
        size = self.projection * .78 / depth
        left = (self.width - 1) / 2 + lateral / depth * self.projection_x - size / 2
        top = scene.horizon + (.57 - z) * self.projection / depth - size / 2
        x0, x1 = max(0, int(left)), min(self.width, int(left + size + 1))
        y0, y1 = max(0, int(top)), min(self.height, int(top + size + 1))
        if x0 >= x1 or y0 >= y1:
            return
        tx = np.clip(((np.arange(x0, x1) - left) / size * 128).astype(int), 0, 127)
        ty = np.clip(((np.arange(y0, y1) - top) / size * 128).astype(int), 0, 127)
        # Only the creature's silhouette enters this pass; its eyes never do.
        _, alpha = self.renderer.ghost_sprite(ghost, scene.time)
        region = scene.depth[y0:y1, x0:x1]
        mask = (alpha[ty[:, None], tx[None, :]] > 0) & (depth < region)
        region[mask] = depth
        scene.labels[y0:y1, x0:x1][mask] = key

    def _diamond_geometry(self, scene, goal):
        """Rasterize a real octahedron's depth so rotation generates proper flow."""
        gx, gy = goal
        z = .66 + math.sin(scene.time * 2.3) * .055
        scene.objects[1] = (gx, gy, z, "diamond", 1.0)
        theta = scene.time * .9
        vertices = [(gx, gy, z + .29), (gx, gy, z - .29)]
        vertices += [(gx + .18 * math.cos(theta + i * math.pi / 2),
                      gy + .18 * math.sin(theta + i * math.pi / 2), z) for i in range(4)]
        c, s = math.cos(scene.angle), math.sin(scene.angle)
        projected = []
        for x, y, pz in vertices:
            dx, dy = x - scene.x, y - scene.y
            depth = dx * c + dy * s
            if depth <= .06:
                return  # The collection radius normally prevents near clipping.
            projected.append(((self.width - 1) / 2 + (-dx * s + dy * c) / depth * self.projection_x,
                              scene.horizon + (.57 - pz) * self.projection / depth, depth))
        faces = [(pole, 2 + i, 2 + (i + 1) % 4) for pole in (0, 1) for i in range(4)]
        for face in faces:
            (ax, ay, ad), (bx, by, bd), (cx, cy, cd) = [projected[v] for v in face]
            x0, x1 = max(0, int(min(ax, bx, cx))), min(self.width, int(max(ax, bx, cx)) + 1)
            y0, y1 = max(0, int(min(ay, by, cy))), min(self.height, int(max(ay, by, cy)) + 1)
            determinant = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
            if x0 >= x1 or y0 >= y1 or abs(determinant) < 1e-7:
                continue
            px, py = self.columns[:, x0:x1], self.rows[y0:y1]
            a = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / determinant
            b = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / determinant
            cc = 1 - a - b
            depth = 1 / np.maximum(a / ad + b / bd + cc / cd, .0001)
            region = scene.depth[y0:y1, x0:x1]
            mask = (a >= 0) & (b >= 0) & (cc >= 0) & (depth < region)
            region[mask] = depth[mask]
            scene.labels[y0:y1, x0:x1][mask] = 1

    def geometry(self, world, pitch=0, bob=0):
        wall_depth, _, _, _, rx, ry = self.renderer.cast(world)
        horizon = self.height * .5 + pitch * self.height + bob
        delta = self.rows - horizon
        plane_depth = np.where(delta >= 0, .57, .68) * self.projection / np.maximum(abs(delta), .0001)
        depth = np.minimum(plane_depth, wall_depth[None, :]).astype(np.float32)
        scene = Scene(world.x, world.y, world.angle, horizon, world.time, depth,
                      np.zeros(depth.shape, dtype=np.int32), rx, ry, {})
        self._diamond_geometry(scene, world.goal)
        live = {}
        for ghost in world.ghosts:
            key = self._ghost_keys.get(id(ghost))
            if key is None:
                key = self._next_ghost_key
                self._next_ghost_key += 1
            live[id(ghost)] = key
            self._ghost_geometry(scene, ghost, key)
        self._ghost_keys = live
        return scene

    def project_previous(self, old, current):
        """Forward correspondences, including moving creatures and goal rotation."""
        x = old.x + old.depth * old.rx[None, :]
        y = old.y + old.depth * old.ry[None, :]
        z = .57 + (old.horizon - self.rows) * old.depth / self.projection
        for key, previous_pose in old.objects.items():
            if key not in current.objects:
                continue
            ox, oy, oz, kind, _ = previous_pose
            nx, ny, nz, _, _ = current.objects[key]
            mask = old.labels == key
            if not mask.any():
                continue
            local_x, local_y = x[mask] - ox, y[mask] - oy
            if kind == "diamond":
                theta = (current.time - old.time) * .9
                c, s = math.cos(theta), math.sin(theta)
                x[mask], y[mask] = nx + c * local_x - s * local_y, ny + s * local_x + c * local_y
            else:
                # Billboard creatures continue to face the viewer.
                lateral = -math.sin(old.angle) * local_x + math.cos(old.angle) * local_y
                x[mask] = nx - math.sin(current.angle) * lateral
                y[mask] = ny + math.cos(current.angle) * lateral
            z[mask] += nz - oz
        dx, dy = x - current.x, y - current.y
        c, s = math.cos(current.angle), math.sin(current.angle)
        depth = dx * c + dy * s
        safe_depth = np.maximum(depth, .001)
        u = (self.width - 1) / 2 + (-dx * s + dy * c) / safe_depth * self.projection_x
        v = current.horizon + (.57 - z) / safe_depth * self.projection
        return u, v, depth

    def transport(self, old, current, coherence, dt):
        u, v, projected_depth = self.project_previous(old, current)
        self.last_flow = (u - self.columns, v - self.rows)
        # Shared stochastic rounding preserves small average motions without the
        # independent per-pixel jitter/density artifacts of random-dot splatting.
        ix = np.floor(u + float(self.rng.random())).astype(np.int32)
        iy = np.floor(v + float(self.rng.random())).astype(np.int32)
        in_view = (projected_depth > .05) & (ix >= 0) & (ix < self.width) & (iy >= 0) & (iy < self.height)
        destination = (np.clip(iy, 0, self.height - 1) * self.width + np.clip(ix, 0, self.width - 1)).ravel()
        visible_depth = current.depth.ravel()[destination].reshape(old.depth.shape)
        visible_label = current.labels.ravel()[destination].reshape(old.depth.shape)
        visible = in_view & (old.labels == visible_label)
        visible &= abs(projected_depth - visible_depth) < (.035 + .04 * visible_depth)
        persistence = float(np.clip(coherence, 0, 1)) ** (dt * 60)
        keep = self.rng.random(self.carrier.shape, dtype=np.float32) < persistence
        for key, (_, _, _, _, opacity) in current.objects.items():
            if opacity < .99:
                keep &= (old.labels != key) | (self.rng.random(self.carrier.shape, dtype=np.float32) < opacity)
        source = self.indices[(visible & keep).ravel()]
        # At most one old value per destination; old values are NEVER duplicated.
        winners = np.full(self.width * self.height, -1, dtype=np.int32)
        np.maximum.at(winners, destination[source], source)
        fresh = self.rng.standard_normal(self.carrier.shape, dtype=np.float32)
        assigned = winners >= 0
        fresh.ravel()[assigned] = self.carrier.ravel()[winners[assigned]]
        self.carrier = fresh
        self.last_source_map = winners.reshape(self.carrier.shape)
        self.retained_fraction = float(assigned.mean())

    def render(self, world, pitch=0, bob=0, coherence=.96):
        key = (id(world.grid), world.seed, world.level, world.time, world.x, world.y,
               world.angle, pitch, bob, coherence,
               tuple((id(g), g.x, g.y, g.age) for g in world.ghosts))
        if key == self.last_key:
            return self.surface  # A paused frame stays perfectly still.
        if self.previous is not None and (self.last_key[:3] != key[:3] or world.time < self.previous.time
                                          or world.time - self.previous.time > .25):
            self.reset()
        current = self.geometry(world, pitch, bob)
        if self.previous is not None:
            dt = current.time - self.previous.time
            # Mouse look may change between two fixed simulation ticks.
            self.transport(self.previous, current, coherence, max(dt, 1 / 120))
        self.gray = self._pink(self.carrier)
        pygame.surfarray.blit_array(self.surface, np.repeat(self.gray.T[:, :, None], 3, axis=2))
        self.previous, self.last_key = current, key
        return self.surface

    def rgb(self, world, pitch=0, coherence=.96):
        """Pixels without HUD; reset() also resets the seeded temporal history."""
        return pygame.surfarray.array3d(self.render(world, pitch, coherence=coherence)).transpose(1, 0, 2)
