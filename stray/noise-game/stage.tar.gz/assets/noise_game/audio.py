"""Small synthesized cues. Sound failure never prevents playing."""

import numpy as np
import pygame


class Audio:
    def __init__(self):
        self.enabled = True
        self.sounds = {}
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 2, 512)
            rate = pygame.mixer.get_init()[0]
            rng = np.random.default_rng(192)
            for name, duration, frequencies in [
                ("spawn", .55, (115, 89)), ("hit", .23, (66, 42)),
                ("evade", .25, (260, 390)), ("win", .9, (330, 440, 660)),
                ("step", .075, (75, 90)),
            ]:
                t = np.arange(int(rate * duration)) / rate
                signal = sum(np.sin(2 * np.pi * f * t) for f in frequencies) / len(frequencies)
                signal += rng.normal(0, .32 if name in ("step", "hit") else .045, len(t))
                signal *= np.sin(np.pi * t / duration) ** 2 * np.exp(-t / duration * 2)
                samples = (signal * (1500 if name == "step" else 4200)).astype(np.int16)
                self.sounds[name] = pygame.sndarray.make_sound(np.column_stack([samples, samples]))
        except pygame.error:
            self.enabled = False

    def play(self, name):
        if self.enabled and name in self.sounds:
            self.sounds[name].play()
