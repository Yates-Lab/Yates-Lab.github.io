"""Headless simulation. No window, audio, wall clock, or input-device dependencies.

Coordinates are in map tiles: x increases east, y increases south. Angle zero
faces east; positive angles turn clockwise. All randomness belongs to the world.
"""

from collections import deque
from dataclasses import dataclass
import math

import numpy as np


@dataclass(frozen=True)
class Config:
    room_count: int = 4
    room_spacing: int = 7
    walk_speed: float = 2.45
    sprint_speed: float = 3.7
    player_radius: float = 0.19
    ghost_speed: float = 2.18
    ghost_lifetime: float = 5.8
    tick_rate: int = 60


@dataclass(frozen=True)
class Action:
    forward: float = 0.0
    strafe: float = 0.0
    turn: float = 0.0  # radians per second
    sprint: bool = False


@dataclass
class Ghost:
    x: float
    y: float
    age: float = 0.0
    lifetime: float = 5.8
    phase: float = 0.0
    waypoint: tuple[float, float] | None = None

    @property
    def opacity(self):
        return max(0.0, min(1.0, self.age / 0.55, (self.lifetime - self.age) / 0.8))

    @property
    def active(self):
        return 0.55 < self.age < self.lifetime - 0.65


def distance_field(grid, target):
    """Four-connected shortest-path distances; -1 denotes unreachable cells."""
    result = np.full(grid.shape, -1, dtype=np.int16)
    tx, ty = target
    if grid[ty, tx]:
        return result
    result[ty, tx] = 0
    queue = deque([(tx, ty)])
    h, w = grid.shape
    while queue:
        x, y = queue.popleft()
        for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= nx < w and 0 <= ny < h and not grid[ny, nx] and result[ny, nx] < 0:
                result[ny, nx] = result[y, x] + 1
                queue.append((nx, ny))
    return result


def generate_maze(rng, config):
    n, spacing = config.room_count, config.room_spacing
    size = n * spacing + 1
    grid = np.ones((size, size), dtype=np.uint8)
    centers, rooms = [], []
    for ry in range(n):
        for rx in range(n):
            cx, cy = spacing // 2 + 1 + rx * spacing, spacing // 2 + 1 + ry * spacing
            hw, hh = int(rng.integers(1, 3)), int(rng.integers(1, 3))
            grid[cy - hh:cy + hh + 1, cx - hw:cx + hw + 1] = 0
            centers.append((cx, cy))
            rooms.append((cx, cy, hw, hh))

    # A spanning tree guarantees reachability; extra doors create escape loops.
    edges, visited, stack = set(), {0}, [0]
    while stack:
        current = stack[-1]
        rx, ry = current % n, current // n
        candidates = [ny * n + nx for nx, ny in
                      ((rx + 1, ry), (rx - 1, ry), (rx, ry + 1), (rx, ry - 1))
                      if 0 <= nx < n and 0 <= ny < n and ny * n + nx not in visited]
        if not candidates:
            stack.pop()
            continue
        nxt = int(rng.choice(candidates))
        edges.add(tuple(sorted((current, nxt))))
        visited.add(nxt)
        stack.append(nxt)
    for a in range(n * n):
        for b in (a + 1, a + n):
            if b < n * n and (b == a + n or a // n == b // n) and rng.random() < 0.19:
                edges.add((a, b))
    for a, b in sorted(edges):
        ax, ay = centers[a]
        bx, by = centers[b]
        grid[min(ay, by):max(ay, by) + 1, min(ax, bx):max(ax, bx) + 1] = 0

    # Pillars in roomy chambers. Their surrounding ring stays open.
    for cx, cy, hw, hh in rooms[1:]:
        if hw == 2 and hh == 2 and rng.random() < 0.75:
            px, py = cx + int(rng.choice([-1, 1])), cy + int(rng.choice([-1, 1]))
            grid[py, px] = 2
    return grid, centers, rooms


class World:
    def __init__(self, seed=1, level=1, config=None, ghosts_enabled=True):
        self.config = config or Config()
        self.ghosts_enabled = bool(ghosts_enabled)
        self.reset(seed, level)

    def set_ghosts_enabled(self, enabled):
        """Keep the maze/run intact; re-enabling gives seven seconds of grace."""
        enabled = bool(enabled)
        if enabled != self.ghosts_enabled:
            self.ghosts_enabled = enabled
            self.next_spawn = 7.0
            if not enabled:
                self.ghosts.clear()

    def reset(self, seed=1, level=1):
        self.seed, self.level = int(seed), int(level)
        self.rng = np.random.default_rng(self.seed)
        self.grid, self.centers, self.rooms = generate_maze(self.rng, self.config)
        sx, sy = self.centers[0]
        self.x, self.y = sx + 0.5, sy + 0.5
        distances = distance_field(self.grid, (sx, sy))
        gx, gy = max(self.centers[1:], key=lambda p: int(distances[p[1], p[0]]))
        self.goal = (gx + 0.5, gy + 0.5)
        self.goal_distances = distance_field(self.grid, (gx, gy))
        # Face an actual exit from the first chamber.
        self.angle = 0.0 if self.grid[sy, sx + 3] == 0 else math.pi / 2
        self.time = 0.0
        self.health = 3
        self.stamina = 1.0
        self.invulnerable = 0.0
        self.damage_flash = 0.0
        self.status = "playing"
        self.ghosts = []
        self.next_spawn = 7.0
        self.spawn_count = 0
        self.evaded = 0
        self.events = []
        self.visited = np.zeros_like(self.grid, dtype=bool)
        self._flow = distances
        self._flow_time = 0.0
        self._reveal()
        return self.observation(), self.info()

    def info(self):
        return {"seed": self.seed, "level": self.level, "time": self.time,
                "status": self.status, "evaded": self.evaded,
                "ghosts_enabled": self.ghosts_enabled,
                "goal_path_distance": int(self.goal_distances[int(self.y), int(self.x)])}

    def observation(self):
        """Privileged state for debugging / future adapters (not a vision agent)."""
        return {"position": np.array([self.x, self.y, self.angle], dtype=np.float32),
                "health": self.health, "stamina": self.stamina,
                "goal": np.array(self.goal, dtype=np.float32),
                "grid": self.grid.copy(),
                "ghosts": np.array([(g.x, g.y, g.age, g.lifetime) for g in self.ghosts],
                                   dtype=np.float32).reshape(-1, 4)}

    def can_stand(self, x, y, radius=None):
        radius = self.config.player_radius if radius is None else radius
        h, w = self.grid.shape
        if x - radius < 0 or y - radius < 0 or x + radius >= w or y + radius >= h:
            return False
        for cy in range(int(y - radius), int(y + radius) + 1):
            for cx in range(int(x - radius), int(x + radius) + 1):
                if self.grid[cy, cx]:
                    near_x, near_y = max(cx, min(x, cx + 1)), max(cy, min(y, cy + 1))
                    if (x - near_x) ** 2 + (y - near_y) ** 2 < radius ** 2:
                        return False
        return True

    def move(self, x, y, dx, dy, radius=None):
        # Substeps prevent tunnelling even for unusually large actions.
        steps = max(1, math.ceil(math.hypot(dx, dy) / 0.09))
        for _ in range(steps):
            if self.can_stand(x + dx / steps, y, radius):
                x += dx / steps
            if self.can_stand(x, y + dy / steps, radius):
                y += dy / steps
        return x, y

    def line_of_sight(self, x, y):
        dx, dy = x - self.x, y - self.y
        steps = max(1, math.ceil(math.hypot(dx, dy) * 12))
        for t in np.linspace(0, 1, steps + 1):
            if self.grid[int(self.y + dy * t), int(self.x + dx * t)]:
                return False
        return True

    def _reveal(self):
        x, y = int(self.x), int(self.y)
        self.visited[max(0, y - 2):y + 3, max(0, x - 2):x + 3] = True

    def _spawn_ghost(self):
        if not self.ghosts_enabled:
            return
        distances = distance_field(self.grid, (int(self.x), int(self.y)))
        ys, xs = np.where((distances >= 5) & (distances <= 10))
        if not len(xs):
            return
        candidates = list(zip(xs.tolist(), ys.tolist()))
        concealed = [(x, y) for x, y in candidates if not self.line_of_sight(x + .5, y + .5)]
        candidates = concealed or candidates
        x, y = candidates[int(self.rng.integers(len(candidates)))]
        self.ghosts.append(Ghost(x + .5, y + .5, lifetime=self.config.ghost_lifetime,
                                 phase=float(self.rng.uniform(0, math.tau))))
        self.spawn_count += 1
        self.events.append("spawn")

    def _tick(self, action, dt):
        self.time += dt
        self.angle = (self.angle + float(np.clip(action.turn, -20, 20)) * dt) % math.tau
        forward, strafe = float(np.clip(action.forward, -1, 1)), float(np.clip(action.strafe, -1, 1))
        magnitude = max(1.0, math.hypot(forward, strafe))
        moving = abs(forward) + abs(strafe) > 0.01
        sprinting = action.sprint and self.stamina > 0.02 and moving
        speed = self.config.sprint_speed if sprinting else self.config.walk_speed
        self.stamina = max(0.0, self.stamina - dt * 0.23) if sprinting else min(1.0, self.stamina + dt * 0.16)
        c, s = math.cos(self.angle), math.sin(self.angle)
        self.x, self.y = self.move(self.x, self.y, (c * forward - s * strafe) * speed * dt / magnitude,
                                  (s * forward + c * strafe) * speed * dt / magnitude)
        self._reveal()
        self.invulnerable = max(0, self.invulnerable - dt)
        self.damage_flash = max(0, self.damage_flash - dt * 2.5)
        self._flow_time -= dt
        if self._flow_time <= 0:
            self._flow = distance_field(self.grid, (int(self.x), int(self.y)))
            self._flow_time = 0.2
        if self.ghosts_enabled:
            self.next_spawn -= dt
        if self.ghosts_enabled and self.next_spawn <= 0:
            if len(self.ghosts) < min(3, 1 + self.level):
                self._spawn_ghost()
            self.next_spawn = float(self.rng.uniform(4.2, 7.0)) / (1 + min(5, self.level - 1) * 0.08)
        survivors = []
        for ghost in self.ghosts:
            ghost.age += dt
            if ghost.age >= ghost.lifetime:
                self.evaded += 1
                self.events.append("evade")
                continue
            if ghost.active:
                cx, cy = int(ghost.x), int(ghost.y)
                if (cx, cy) == (int(self.x), int(self.y)):
                    tx, ty = self.x, self.y
                    ghost.waypoint = None
                else:
                    if ghost.waypoint is None or math.dist((ghost.x, ghost.y), ghost.waypoint) < .08:
                        candidates = [(nx, ny) for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1))
                                      if 0 <= ny < self.grid.shape[0] and 0 <= nx < self.grid.shape[1]
                                      and self._flow[ny, nx] >= 0]
                        if candidates:
                            nx, ny = min(candidates, key=lambda p: self._flow[p[1], p[0]])
                            ghost.waypoint = (nx + .5, ny + .5)
                    tx, ty = ghost.waypoint or (ghost.x, ghost.y)
                dx, dy = tx - ghost.x, ty - ghost.y
                length = math.hypot(dx, dy)
                if length > 0.001:
                    step = min(length, (self.config.ghost_speed + min(6, self.level - 1) * .05) * dt)
                    ghost.x, ghost.y = self.move(ghost.x, ghost.y, dx / length * step, dy / length * step, .16)
                if math.hypot(ghost.x - self.x, ghost.y - self.y) < .43 and self.invulnerable <= 0:
                    self.health -= 1
                    self.invulnerable, self.damage_flash = 1.75, 1.0
                    self.events.append("hit")
                    if self.health <= 0:
                        self.status = "lost"
                    continue
            survivors.append(ghost)
        self.ghosts = survivors
        if self.status == "playing" and math.dist((self.x, self.y), self.goal) < .55:
            self.status = "won"
            self.events.append("win")

    def step(self, action, dt=None):
        """Gym-like step result. Rendering and episode resets stay with the caller.

        Rewards are provisional: +1 goal, -1 death, -.15 hit, -.001 per second.
        dt is simulated time, never read from the operating-system clock.
        """
        dt = 1 / self.config.tick_rate if dt is None else float(dt)
        if not math.isfinite(dt) or dt <= 0 or dt > 1:
            raise ValueError("dt must be finite, greater than zero and at most one second")
        self.events = []
        if self.status != "playing":
            return self.observation(), 0.0, True, False, self.info()
        remaining = dt
        while remaining > 1e-9 and self.status == "playing":
            tick = min(remaining, 1 / self.config.tick_rate)
            self._tick(action, tick)
            remaining -= tick
        reward = -.001 * (dt - remaining) - .15 * self.events.count("hit")
        reward += 1.0 if self.status == "won" else -1.0 if self.status == "lost" else 0.0
        return self.observation(), reward, self.status != "playing", False, self.info()
