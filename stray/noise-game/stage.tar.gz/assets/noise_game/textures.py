"""Seamless monochrome textures with a radial power spectrum proportional to 1/f."""

import numpy as np


def pink_noise(size=128, seed=0):
    rng = np.random.default_rng(seed)
    white = rng.normal(size=(size, size))
    fx = np.fft.rfftfreq(size)[None, :]
    fy = np.fft.fftfreq(size)[:, None]
    frequency = np.hypot(fx, fy)
    frequency[0, 0] = 1.0
    # Power = amplitude squared, so amplitude is scaled by 1/sqrt(f).
    spectrum = np.fft.rfft2(white) / np.sqrt(frequency)
    spectrum[0, 0] = 0
    noise = np.fft.irfft2(spectrum, s=(size, size), axes=(0, 1))
    return (noise / max(noise.std(), 1e-9)).astype(np.float32)


def texture(size, seed, mean, contrast):
    return np.clip(mean + pink_noise(size, seed) * contrast, 0, 255).astype(np.uint8)


class Textures:
    def __init__(self, seed=712):
        self.size = 128
        self.wall = texture(128, seed, 151, 29)
        self.wall_alt = texture(128, seed + 1, 127, 30)
        self.pillar = texture(128, seed + 2, 96, 33)
        self.floor = texture(128, seed + 3, 100, 21)
        self.ceiling = texture(128, seed + 4, 92, 20)
        self.ghost = texture(128, seed + 5, 155, 39)
        self.diamond = texture(128, seed + 6, 214, 23)
        self.walls = np.stack([self.wall, self.wall_alt, self.pillar])
