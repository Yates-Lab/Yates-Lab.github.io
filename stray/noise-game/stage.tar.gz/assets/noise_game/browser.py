"""Browser adapter: the simulation and both renderers remain shared with desktop."""

import asyncio
from collections import deque
import json
import math
import time

import pygame

from .app import Game
from .core import Action
from .motion import MotionRenderer
from .renderer import Renderer

SIZES = {"fast": (320, 180), "balanced": (480, 270), "sharp": (640, 360)}
STORAGE_KEY = "noise-game.settings.v1"


class BrowserGame(Game):
    def __init__(self, window=None, seed=None):
        if window is None:
            from platform import window
        self.window = window
        self.quality = "fast"
        self._published = None
        self._report_at = 0.0
        self._timings = deque(maxlen=120)
        self._frame_count = 0
        self._keys = set()
        self._taps = set()
        self._pref_cache = {}
        super().__init__(seed=seed, render_size=SIZES[self.quality])
        self.set_quality(self.quality)

    def read_preferences(self):
        try:
            raw = self.window.localStorage.getItem(STORAGE_KEY)
            prefs = json.loads(str(raw)) if raw else {}
            if not isinstance(prefs, dict):
                return {}
            self.quality = prefs.get("quality", "fast")
            if self.quality not in SIZES:
                self.quality = "fast"
            self._pref_cache = prefs
            return prefs
        except Exception:
            return {}

    def write_preferences(self, prefs):
        prefs["quality"] = self.quality
        if prefs == self._pref_cache:
            return
        try:
            self.window.localStorage.setItem(STORAGE_KEY, json.dumps(prefs))
            self._pref_cache = prefs.copy()
        except Exception:
            pass  # Private browsing / disabled storage still permits play.

    def set_quality(self, quality):
        if quality not in SIZES:
            return
        self.quality = quality
        size = SIZES[quality]
        if (self.renderer.width, self.renderer.height) != size:
            self.renderer = Renderer(size)
            self.motion_renderer = MotionRenderer(self.renderer)
        self._save_prefs()

    def capture(self, enabled):
        # Actual pointer-lock requests happen inside trusted DOM click/key events.
        # Python runs asynchronously, outside the browser's user-activation scope.
        self.window.noiseBridge.setCapture(bool(enabled))
        self._keys.clear()
        self._taps.clear()
        pygame.mouse.set_visible(not enabled)
        pygame.mouse.get_rel()

    def toggle_fullscreen(self):
        # The F key is handled synchronously in the browser's DOM event handler.
        pass

    def font(self, size, mono=False, bold=False):
        key = size, mono, bold
        if key not in self.fonts:
            # Pygame's bundled font is distributable and available in WebAssembly.
            font = pygame.font.Font(None, round(size * 1.35))
            font.set_bold(bold)
            self.fonts[key] = font
        return self.fonts[key]

    def text(self, text, *args, **kwargs):
        # The bundled font does not include the desktop return-arrow glyph.
        super().text(text.replace("↵", ""), *args, **kwargs)

    def events(self):
        # DOM movementX/Y is reliable under pointer lock; don't double-apply SDL motion.
        pygame.event.get(pygame.MOUSEMOTION)
        super().events()
        state = json.loads(str(self.window.noiseBridge.poll()))
        self._keys = set(state.get("keys", ()))
        self._taps.update(state.get("taps", ()))
        if state.get("quality"):
            self.set_quality(state["quality"])
        if state.get("pause") and self.mode == "playing":
            self.mode = "paused"
            self.map_open = self.freeze_frame = False
            self.capture(False)
        if self.mode == "playing" and not self.map_open and not self.freeze_frame:
            dx, dy = state.get("dx", 0), state.get("dy", 0)
            self.world.angle = (self.world.angle + dx * self.sensitivity) % math.tau
            self.pitch = max(-.32, min(.32, self.pitch - dy * self.sensitivity * .55))

    def input_action(self):
        # Keep short taps until a simulation step; asynchronous frames can otherwise miss them.
        keys = self._keys | self._taps
        self._taps.clear()
        return Action(float(bool(keys & {"KeyW", "ArrowUp"})) - float(bool(keys & {"KeyS", "ArrowDown"})),
                      float("KeyD" in keys) - float("KeyA" in keys),
                      (float("ArrowRight" in keys) - float("ArrowLeft" in keys)) * 1.9,
                      bool(keys & {"ShiftLeft", "ShiftRight"}))

    def update(self, dt):
        if self.mode == "playing" and not self.map_open and not self.freeze_frame:
            if not self.window.noiseBridge.locked():
                self.accumulator = 0
                return
        super().update(dt)

    def publish(self):
        stamp = time.perf_counter()
        state = {"mode": self.mode, "map": self.map_open, "frozen": self.freeze_frame,
                 "world": self.visual_mode, "coherence": self.coherence,
                 "ghosts": self.world.ghosts_enabled, "quality": self.quality,
                 "seed": self.world.seed, "starts": [list(rect) for key, rect in self.buttons if key in ("primary", "new")]}
        encoded = json.dumps(state)
        if encoded != self._published:
            self.window.noiseBridge.update(encoded)
            self._published = encoded
        if stamp >= self._report_at:
            avg = sum(self._timings) / max(1, len(self._timings))
            report = {"fps": round(self.clock.get_fps(), 1), "frame_ms": round(avg * 1000, 1),
                      "frames": self._frame_count, "x": round(self.world.x, 3), "y": round(self.world.y, 3),
                      "angle": round(self.world.angle, 3), "time": round(self.world.time, 2),
                      "health": self.world.health, "ghost_count": len(self.world.ghosts),
                      "retained": round(self.motion_renderer.retained_fraction, 3)}
            self.window.noiseBridge.report(json.dumps(report))
            self._report_at = stamp + .5
            self._save_prefs()

    async def run_browser(self):
        try:
            while self.running:
                dt = min(self.clock.tick(0) / 1000, .1)
                started = time.perf_counter()
                self.events()
                self.update(dt)
                self.draw()
                self._timings.append(time.perf_counter() - started)
                self._frame_count += 1
                self.publish()
                await asyncio.sleep(0)
        finally:
            self.capture(False)
            self._save_prefs()
