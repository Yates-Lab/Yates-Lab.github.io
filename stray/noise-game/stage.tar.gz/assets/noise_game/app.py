import argparse
import json
import math
import os
from pathlib import Path
import secrets
import time

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

import numpy as np
import pygame

from .audio import Audio
from .core import Action, World
from .motion import MotionRenderer
from .renderer import Renderer

ROOT = Path(__file__).resolve().parent.parent
PREFS = Path.home() / ".config" / "noise-game" / "settings.json"


class Game:
    def __init__(self, seed=None, muted=False, render_size=(640, 360)):
        pygame.mixer.pre_init(22050, -16, 2, 512)
        pygame.init()
        pygame.display.set_caption("NOISE — Find the diamond")
        self.screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)
        self.canvas = pygame.Surface((1280, 720))
        self.hud_shade = pygame.Surface((1280, 720), pygame.SRCALPHA)
        for y in range(112):
            alpha = int(138 * (1 - y / 112))
            pygame.draw.line(self.hud_shade, (0, 0, 0, alpha), (0, y), (1280, y))
            pygame.draw.line(self.hud_shade, (0, 0, 0, alpha), (0, 719 - y), (1280, 719 - y))
        self.clock = pygame.time.Clock()
        self.renderer = Renderer(render_size)
        self.motion_renderer = MotionRenderer(self.renderer)
        self.audio = Audio()
        self.world = World(seed if seed is not None else secrets.randbelow(9_000_000) + 1_000_000)
        self.mode = "title"
        self.map_open = False
        self.running = True
        self.fullscreen = False
        self.pitch = 0.0
        self.sensitivity = .0022
        self.head_bob = False
        self.fonts = {}
        self.buttons = []
        self.elapsed = 0.0
        self.move_time = 0.0
        self.footstep = 0.0
        self.accumulator = 0.0
        self.show_fps = False
        self.visual_mode = "classic"
        self.coherence = .96
        self.show_hud = True
        self.freeze_frame = False
        self._load_prefs()
        if muted:
            self.audio.enabled = False
        self.capture(False)

    def read_preferences(self):
        return json.loads(PREFS.read_text())

    def write_preferences(self, prefs):
        PREFS.parent.mkdir(parents=True, exist_ok=True)
        PREFS.write_text(json.dumps(prefs, indent=2))

    def _load_prefs(self):
        try:
            prefs = self.read_preferences()
            self.sensitivity = max(.0007, min(.006, float(prefs.get("sensitivity", .0022))))
            self.head_bob = bool(prefs.get("head_bob", False))
            self.audio.enabled = bool(prefs.get("sound", True)) and bool(self.audio.sounds)
            self.visual_mode = "motion" if prefs.get("visual_mode") == "motion" else "classic"
            self.coherence = max(.75, min(.995, float(prefs.get("coherence", .96))))
            self.show_hud = bool(prefs.get("show_hud", True))
            self.world.set_ghosts_enabled(bool(prefs.get("ghosts_enabled", True)))
        except (OSError, ValueError, TypeError):
            pass

    def _save_prefs(self):
        try:
            self.write_preferences({"sensitivity": self.sensitivity,
                                        "head_bob": self.head_bob, "sound": self.audio.enabled,
                                        "visual_mode": self.visual_mode, "coherence": self.coherence,
                                        "show_hud": self.show_hud,
                                        "ghosts_enabled": self.world.ghosts_enabled})
        except OSError:
            pass

    def capture(self, enabled):
        pygame.event.set_grab(enabled)
        pygame.mouse.set_visible(not enabled)
        if hasattr(pygame.mouse, "set_relative_mode"):
            try:
                pygame.mouse.set_relative_mode(enabled)
            except pygame.error:
                pass  # Dummy/older drivers fall back to hidden-cursor mouse grab.
        pygame.mouse.get_rel()

    def font(self, size, mono=False, bold=False):
        key = size, mono, bold
        if key not in self.fonts:
            if os.sys.platform == "darwin":
                path = "/System/Library/Fonts/Menlo.ttc" if mono else "/System/Library/Fonts/Avenir Next.ttc"
                if not Path(path).exists():
                    path = None
                font = pygame.font.Font(path, size)
                font.set_bold(bold)
            else:
                font = pygame.font.SysFont("consolas" if mono else "arial", size, bold)
            self.fonts[key] = font
        return self.fonts[key]

    def text(self, text, x, y, size=18, color=220, mono=False, bold=False, right=False):
        surf = self.font(size, mono, bold).render(text, True, (color,) * 3)
        self.canvas.blit(surf, (x - surf.get_width() if right else x, y))

    def line(self, x1, y1, x2, y2, color=85, width=1):
        pygame.draw.line(self.canvas, (color,) * 3, (x1, y1), (x2, y2), width)

    def diamond(self, x, y, radius=9, color=230, width=1):
        pygame.draw.polygon(self.canvas, (color,) * 3,
                            [(x, y - radius), (x + radius * .62, y), (x, y + radius), (x - radius * .62, y)], width)

    def mouse(self, position=None):
        x, y = pygame.mouse.get_pos() if position is None else position
        w, h = self.screen.get_size()
        return x * 1280 / w, y * 720 / h

    def button(self, key, label, rect, primary=False):
        rect = pygame.Rect(rect)
        hover = rect.collidepoint(self.mouse())
        if primary:
            pygame.draw.rect(self.canvas, (250 if hover else 225,) * 3, rect)
            color = 16
        else:
            pygame.draw.rect(self.canvas, (42 if hover else 23,) * 3, rect)
            pygame.draw.rect(self.canvas, (95 if hover else 62,) * 3, rect, 1)
            color = 230
        self.text(label, rect.x + 21, rect.y + 13, 17, color, mono=True)
        self.buttons.append((key, rect))

    def resume(self):
        self.mode = "playing"
        self.map_open = False
        self.freeze_frame = False
        self.accumulator = 0
        self.capture(True)

    def new_level(self, retry=False):
        level = self.world.level if retry else self.world.level + (self.world.status == "won")
        seed = self.world.seed if retry else secrets.randbelow(9_000_000) + 1_000_000
        self.world.reset(seed, level)
        self.motion_renderer.reset()
        self.pitch = self.move_time = self.footstep = 0.0
        self.resume()

    def activate(self, key):
        if key == "primary":
            if self.world.status == "won":
                self.new_level()
            elif self.world.status == "lost":
                self.new_level(True)
            else:
                self.resume()
        elif key == "new":
            self.new_level()
        elif key == "quit":
            self.running = False
        elif key in ("slower", "faster"):
            self.sensitivity = max(.0007, min(.006, self.sensitivity + (.0003 if key == "faster" else -.0003)))
        elif key == "sound":
            self.audio.enabled = not self.audio.enabled
        elif key == "bob":
            self.head_bob = not self.head_bob
        elif key == "ghosts":
            self.world.set_ghosts_enabled(not self.world.ghosts_enabled)
        elif key in ("classic", "motion"):
            self.visual_mode = key
            self.motion_renderer.reset()
        elif key in ("less_coherent", "more_coherent"):
            self.coherence = round(max(.75, min(.995, self.coherence + (.01 if key == "more_coherent" else -.01))), 3)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN) if self.fullscreen else pygame.display.set_mode((1280, 720), pygame.RESIZABLE)
        self.capture(self.mode == "playing" and not self.map_open and not self.freeze_frame)

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.WINDOWFOCUSLOST and self.mode == "playing":
                self.mode = "paused"
                self.map_open = False
                self.freeze_frame = False
                self.capture(False)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.map_open:
                        self.map_open = False
                        self.capture(not self.freeze_frame)
                    elif self.freeze_frame:
                        self.freeze_frame = False
                        self.capture(True)
                    elif self.mode == "playing":
                        self.mode = "paused"
                        self.capture(False)
                    elif self.mode == "paused":
                        self.resume()
                elif event.key == pygame.K_RETURN and self.mode != "playing":
                    self.activate("primary")
                elif event.key in (pygame.K_1, pygame.K_2) and self.mode != "playing":
                    self.activate("motion" if event.key == pygame.K_2 else "classic")
                elif event.key == pygame.K_TAB and self.mode == "playing":
                    self.map_open = not self.map_open
                    self.accumulator = 0
                    self.capture(not self.map_open and not self.freeze_frame)
                elif event.key == pygame.K_SPACE and self.mode == "playing" and not self.map_open:
                    self.freeze_frame = not self.freeze_frame
                    self.accumulator = 0
                    self.capture(not self.freeze_frame)
                elif event.key == pygame.K_h:
                    self.show_hud = not self.show_hud
                elif event.key == pygame.K_f:
                    self.toggle_fullscreen()
                elif event.key == pygame.K_m:
                    self.activate("sound")
                elif event.key == pygame.K_b:
                    self.activate("bob")
                elif event.key == pygame.K_MINUS:
                    self.activate("slower")
                elif event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                    self.activate("faster")
                elif event.key == pygame.K_F3:
                    self.show_fps = not self.show_fps
                elif event.key == pygame.K_F12:
                    folder = ROOT / "artifacts"
                    folder.mkdir(exist_ok=True)
                    pygame.image.save(self.canvas, folder / f"noise-{int(time.time())}.png")
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.mode != "playing":
                for key, rect in self.buttons:
                    if rect.collidepoint(self.mouse(event.pos)):
                        self.activate(key)
                        break
            elif event.type == pygame.MOUSEMOTION and self.mode == "playing" and not self.map_open and not self.freeze_frame:
                self.world.angle = (self.world.angle + event.rel[0] * self.sensitivity) % math.tau
                self.pitch = max(-.32, min(.32, self.pitch - event.rel[1] * self.sensitivity * .55))

    def input_action(self):
        keys = pygame.key.get_pressed()
        return Action(float(keys[pygame.K_w] or keys[pygame.K_UP]) - float(keys[pygame.K_s] or keys[pygame.K_DOWN]),
                      float(keys[pygame.K_d]) - float(keys[pygame.K_a]),
                      (float(keys[pygame.K_RIGHT]) - float(keys[pygame.K_LEFT])) * 1.9,
                      bool(keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]))

    def update(self, dt):
        self.elapsed += dt
        if self.mode != "playing" or self.map_open or self.freeze_frame:
            return
        self.accumulator += min(dt, .1)
        while self.accumulator >= 1 / 60:
            before = (self.world.x, self.world.y)
            self.world.step(self.input_action())
            moved = math.dist(before, (self.world.x, self.world.y))
            self.move_time += moved * 2.2
            self.footstep += moved
            if self.footstep > .95:
                self.footstep = 0
                self.audio.play("step")
            for event in self.world.events:
                self.audio.play(event)
            self.accumulator -= 1 / 60
            if self.world.status != "playing":
                self.mode = "result"
                self.map_open = False
                self.capture(False)
                break

    def hud(self):
        self.canvas.blit(self.hud_shade, (0, 0))
        self.text(f"NOISE  /  {self.world.level:02d}", 38, 29, 21, 232, mono=True)
        self.diamond(44, 78, 7)
        self.text("FIND THE DIAMOND", 62, 66, 14, 185, mono=True)
        seconds = int(self.world.time)
        self.text(f"{seconds // 60:02d}:{seconds % 60:02d}", 1242, 29, 23, 230, mono=True, right=True)
        self.text(f"SEED {self.world.seed}", 1242, 66, 12, 138, mono=True, right=True)
        self.text("RESOLVE", 38, 614, 12, 170, mono=True)
        for i in range(3):
            rect = (38 + i * 27, 642, 17, 17)
            pygame.draw.rect(self.canvas, (220 if i < self.world.health else 70,) * 3, rect, 0 if i < self.world.health else 1)
        self.text("BREATH", 156, 614, 12, 170, mono=True)
        pygame.draw.rect(self.canvas, (64,) * 3, (156, 648, 130, 3))
        pygame.draw.rect(self.canvas, (205,) * 3, (156, 648, int(130 * self.world.stamina), 3))
        self.text("SHIFT  RUN     TAB  MAP     ESC  PAUSE", 1242, 647, 12, 168, mono=True, right=True)
        self.line(38, 691, 1242, 691, 50)
        footer = "MOTION WORLD  /  SPACE FREEZE  /  H HIDE HUD" if self.visual_mode == "motion" else "01 / LOCATE   02 / EVADE   03 / ESCAPE"
        self.text(footer, 38, 697, 10, 150, mono=True)
        pygame.draw.circle(self.canvas, (195,) * 3, (640, 360), 2, 1)
        if self.world.ghosts:
            life = max(g.lifetime - g.age for g in self.world.ghosts)
            label = "A PRESENCE IS FORMING" if all(g.age < .55 for g in self.world.ghosts) else "KEEP MOVING"
            self.text(label, 640 - self.font(13, True).size(label)[0] / 2, 39, 13, 225, mono=True)
            pygame.draw.rect(self.canvas, (60,) * 3, (580, 66, 120, 2))
            pygame.draw.rect(self.canvas, (202,) * 3, (580, 66, int(120 * life / self.world.config.ghost_lifetime), 2))
        elif self.world.time < 6:
            hint = "Strafe to reveal the maze. Space freezes the image." if self.visual_mode == "motion" else "WASD to move. Mouse to look. Find a way through."
            self.text(hint, 397, 576, 17, 220)
        if self.show_fps:
            self.text(f"{self.clock.get_fps():.0f} FPS", 1242, 697, 10, 150, mono=True, right=True)

    def menu(self):
        overlay = pygame.Surface((1280, 720), pygame.SRCALPHA)
        for x in range(1280):
            alpha = int(239 - 115 * (x / 1280) ** 1.8)
            pygame.draw.line(overlay, (8, 8, 8, alpha), (x, 0), (x, 720))
        self.canvas.blit(overlay, (0, 0))
        self.text("N / 01", 56, 32, 18, 225, mono=True)
        self.text("A PROCEDURAL MAZE EXPERIMENT", 1224, 37, 12, 180, mono=True, right=True)
        self.line(56, 80, 1224, 80, 72)
        if self.mode == "title":
            eyebrow, title, subtitle = "FIND A WAY THROUGH", "NOISE", "Find the diamond. Stay ahead of what follows."
            if not self.world.ghosts_enabled:
                subtitle = "Find the diamond. Explore at your own pace."
            if self.visual_mode == "motion":
                eyebrow, subtitle = "SEE THROUGH MOVEMENT", "A world that reveals itself only when things move."
            label = "ENTER THE MAZE          ↵"
        elif self.mode == "paused":
            eyebrow, title, subtitle = "TAKE A BREATH", "PAUSED", "The maze can wait."
            label = "RESUME                  ↵"
        elif self.world.status == "won":
            eyebrow, title = "SIGNAL FOUND", "FOUND."
            subtitle = f"{self.world.time:.1f} seconds. {self.world.evaded} presences outlasted. A new maze awaits."
            label = "NEXT MAZE               ↵"
        else:
            eyebrow, title, subtitle = "LOST IN THE STATIC", "CAUGHT.", "Keep moving. They can only stay for a few seconds."
            label = "TRY THIS MAZE AGAIN     ↵"
        self.text(eyebrow, 60, 116, 13, 162, mono=True)
        self.text(title, 50, 140, 104, 237, bold=True)
        self.text(subtitle, 60, 277, 20, 197)
        self.button("primary", label, (60, 337, 332, 53), True)
        self.button("new", "NEW RANDOM MAZE", (408, 337, 232, 53))
        self.text("MOVE", 60, 428, 12, 130, mono=True)
        self.text("W A S D", 60, 451, 19, 230, mono=True)
        self.text("LOOK", 227, 428, 12, 130, mono=True)
        self.text("MOUSE", 227, 451, 19, 230, mono=True)
        self.text("RUN", 388, 428, 12, 130, mono=True)
        self.text("SHIFT", 388, 451, 19, 230, mono=True)
        self.text("MAP", 543, 428, 12, 130, mono=True)
        self.text("TAB", 543, 451, 19, 230, mono=True)
        self.line(60, 506, 640, 506, 60)
        self.text("MOUSE SENSITIVITY", 60, 528, 11, 155, mono=True)
        self.button("slower", "−", (60, 555, 52, 46))
        self.text(f"{self.sensitivity / .0022:.1f}×", 130, 564, 16, 220, mono=True)
        self.button("faster", "+", (186, 555, 52, 46))
        self.button("sound", f"SOUND {'ON' if self.audio.enabled else 'OFF'}", (262, 555, 161, 46))
        self.button("bob", f"BOB {'ON' if self.head_bob else 'OFF'}", (442, 555, 142, 46))
        self.button("ghosts", f"GHOSTS {'ON' if self.world.ghosts_enabled else 'OFF'}", (604, 555, 180, 46))
        # The recognizable icon is menu artwork only, never a motion-world cue.
        gray, alpha = self.renderer.diamond_sprite(self.elapsed)
        art = pygame.Surface((128, 128), pygame.SRCALPHA)
        pygame.surfarray.pixels3d(art)[:] = np.repeat(gray.T[:, :, None], 3, axis=2)
        pygame.surfarray.pixels_alpha(art)[:] = alpha.T
        self.canvas.blit(pygame.transform.scale(art, (250, 250)), (884, 146))
        self.text("CHOOSE YOUR WORLD", 814, 418, 12, 173, mono=True)
        self.button("classic", "1 CLASSIC", (814, 445, 159, 48), self.visual_mode == "classic")
        self.button("motion", "2 MOTION WORLD", (985, 445, 223, 48), self.visual_mode == "motion")
        if self.visual_mode == "motion":
            self.text("COHERENCE", 814, 515, 12, 178, mono=True)
            self.text(f"{self.coherence * 100:g}%", 948, 509, 20, 231, mono=True)
            self.button("less_coherent", "−", (1088, 507, 52, 43))
            self.button("more_coherent", "+", (1156, 507, 52, 43))
            self.text("Higher = clearer motion. Lower = more renewal.", 814, 566, 14, 182)
            self.text("Strafe to see depth. SPACE freezes a clean frame.", 814, 591, 14, 182)
        else:
            self.text("Surface textures, light, and shadow.", 814, 520, 16, 188)
            self.text("Try Motion World to navigate by optic flow.", 814, 551, 15, 158)
        self.line(56, 650, 1224, 650, 72)
        self.text(f"MAZE {self.world.level:02d}   /   SEED {self.world.seed}", 60, 673, 12, 145, mono=True)
        self.text("F  FULLSCREEN     ESC  PAUSE", 1224, 673, 12, 145, mono=True, right=True)

    def draw_map(self):
        overlay = pygame.Surface((1280, 720), pygame.SRCALPHA)
        overlay.fill((9, 9, 9, 240))
        self.canvas.blit(overlay, (0, 0))
        self.text("SURVEY", 60, 40, 28, 235, bold=True)
        self.text("Explored passages / time paused", 60, 80, 16, 150)
        cell = 17
        size = self.world.grid.shape[0]
        ox, oy = (1280 - size * cell) // 2, 121
        for y in range(size):
            for x in range(size):
                if self.world.visited[y, x]:
                    value = 45 if self.world.grid[y, x] else 125
                    pygame.draw.rect(self.canvas, (value,) * 3, (ox + x * cell, oy + y * cell, cell - 1, cell - 1))
        x, y = ox + self.world.x * cell, oy + self.world.y * cell
        pygame.draw.circle(self.canvas, (250,) * 3, (x, y), 4)
        self.line(x, y, x + math.cos(self.world.angle) * 14, y + math.sin(self.world.angle) * 14, 250, 2)
        gx, gy = self.world.goal
        if self.world.visited[int(gy), int(gx)]:
            self.diamond(ox + gx * cell, oy + gy * cell, 8)
        self.text("TAB  RETURN TO THE MAZE", 493, 661, 15, 215, mono=True)

    def draw(self):
        self.buttons = []
        bob = math.sin(self.move_time * math.tau) * 1.2 if self.head_bob else 0
        scene = self.motion_renderer.render(self.world, self.pitch, bob, self.coherence) if self.visual_mode == "motion" else self.renderer.render(self.world, self.pitch, bob)
        pygame.transform.scale(scene, (1280, 720), self.canvas)
        if self.mode == "playing":
            if self.show_hud and not self.freeze_frame:
                self.hud()
            if self.map_open:
                self.draw_map()
        else:
            self.menu()
        pygame.transform.scale(self.canvas, self.screen.get_size(), self.screen)
        pygame.display.flip()

    def run(self):
        try:
            while self.running:
                dt = self.clock.tick(60) / 1000
                self.events()
                self.update(dt)
                self.draw()
        finally:
            self.capture(False)
            self._save_prefs()
            pygame.quit()


def main():
    parser = argparse.ArgumentParser(description="NOISE — Find the diamond")
    parser.add_argument("--seed", type=int, help="Replay a particular maze")
    parser.add_argument("--mute", action="store_true")
    parser.add_argument("--motion", action="store_true", help="Select Motion World on the launch screen")
    parser.add_argument("--coherence", type=float, help="Motion persistence from .75 to .995 (default .96)")
    parser.add_argument("--screenshot", type=Path, help="Render the title screen and exit")
    args = parser.parse_args()
    game = Game(args.seed, args.mute)
    if args.motion:
        game.visual_mode = "motion"
    if args.coherence is not None:
        game.coherence = max(.75, min(.995, args.coherence))
    if args.screenshot:
        game.draw()
        args.screenshot.parent.mkdir(parents=True, exist_ok=True)
        pygame.image.save(game.canvas, args.screenshot)
        pygame.quit()
    else:
        game.run()


if __name__ == "__main__":
    main()
