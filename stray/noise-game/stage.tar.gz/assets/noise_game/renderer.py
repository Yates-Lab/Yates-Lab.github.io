"""Vectorized 2.5D renderer. Low-resolution world, crisp full-resolution interface."""

import math

import numpy as np
import pygame

from .textures import Textures


class Renderer:
    def __init__(self, size=(640, 360)):
        self.textures = Textures()
        self.resize(size)
        self._ghost_y, self._ghost_x = np.mgrid[0:128, 0:128].astype(np.float32) / 127
        self._diamond_frame = -1
        self._diamond = None

    def resize(self, size):
        self.width, self.height = size
        self.plane = np.linspace(-1, 1, self.width, dtype=np.float32) * math.tan(math.radians(78) / 2)
        self.projection = self.width / (2 * math.tan(math.radians(78) / 2))
        self.rows = np.arange(self.height, dtype=np.float32)[:, None]
        xx = np.linspace(-1, 1, self.width)[None, :]
        yy = np.linspace(-1, 1, self.height)[:, None]
        self.vignette = np.clip(1 - .16 * xx ** 2 - .12 * yy ** 2, .65, 1).astype(np.float32)
        self.surface = pygame.Surface(size)

    def cast(self, world):
        c, s = math.cos(world.angle), math.sin(world.angle)
        rx, ry = c - s * self.plane, s + c * self.plane
        mx = np.full(self.width, int(world.x), dtype=np.int32)
        my = np.full(self.width, int(world.y), dtype=np.int32)
        dx, dy = 1 / np.maximum(np.abs(rx), 1e-8), 1 / np.maximum(np.abs(ry), 1e-8)
        sx, sy = np.where(rx < 0, -1, 1), np.where(ry < 0, -1, 1)
        side_x = np.where(rx < 0, world.x - mx, mx + 1 - world.x) * dx
        side_y = np.where(ry < 0, world.y - my, my + 1 - world.y) * dy
        active = np.ones(self.width, dtype=bool)
        distances = np.full(self.width, 48, dtype=np.float32)
        sides = np.zeros(self.width, dtype=bool)
        types = np.ones(self.width, dtype=np.uint8)
        for _ in range(world.grid.shape[0] * 2):
            cross_x = side_x < side_y
            along_x, along_y = active & cross_x, active & ~cross_x
            mx += along_x * sx
            my += along_y * sy
            travel = np.where(cross_x, side_x, side_y)
            side_x += along_x * dx
            side_y += along_y * dy
            tiles = world.grid[np.clip(my, 0, world.grid.shape[0] - 1),
                               np.clip(mx, 0, world.grid.shape[1] - 1)]
            hit = active & (tiles != 0)
            distances[hit] = travel[hit]
            sides[hit] = ~cross_x[hit]
            types[hit] = tiles[hit]
            active[hit] = False
            if not active.any():
                break
        coordinate = np.where(sides, world.x + distances * rx, world.y + distances * ry)
        tex_x = (coordinate * 128).astype(np.int32) % 128
        material = np.where(types == 2, 2, (mx * 7 + my * 11) % 5 == 0).astype(np.int32)
        return np.maximum(.025, distances), sides, material, tex_x, rx, ry

    @staticmethod
    def light(distance):
        return .12 + .88 / (1 + .095 * distance + .018 * distance ** 2)

    def ghost_sprite(self, ghost, time):
        x, y = self._ghost_x, self._ghost_y
        wobble = .018 * np.sin(time * 7 + y * 11 + ghost.phase)
        body_x = x - .5 + wobble
        dome = (body_x / .335) ** 2 + ((y - .42) / .32) ** 2 < 1
        scallop = .83 + .045 * np.sin(x * 36 + time * 9 + ghost.phase)
        body = ((abs(body_x) < .335) & (y >= .4) & (y < scallop)) | dome
        alpha = body.astype(np.float32) * ghost.opacity
        # Dissolution eats into the same 1/f noise that textures the creature.
        if ghost.opacity < .98:
            alpha *= np.clip((self.textures.ghost / 255 - (1 - ghost.opacity) * .9) * 7, 0, 1)
        shade = np.clip(1.15 - abs(body_x) * 1.45, .4, 1.1)
        gray = self.textures.ghost.astype(np.float32) * shade + 15
        for eye_x in (.39, .62):
            eye = ((x - eye_x) / .079) ** 2 + ((y - .405) / .115) ** 2 < 1
            pupil = ((x - eye_x + .006) / .027) ** 2 + ((y - .412) / .052) ** 2 < 1
            gray[eye] = 235
            gray[pupil] = 12
        return np.clip(gray, 0, 255).astype(np.uint8), (alpha * 255).astype(np.uint8)

    def diamond_sprite(self, time):
        frame = int(time * 20)
        if frame == self._diamond_frame:
            return self._diamond
        self._diamond_frame = frame
        angle = time * .9
        verts = [(0, -.44, 0), (0, .44, 0)]
        verts += [(math.cos(angle + i * math.pi / 2) * .27, 0,
                   math.sin(angle + i * math.pi / 2) * .27) for i in range(4)]
        faces = [(0, 2 + i, 2 + (i + 1) % 4) for i in range(4)]
        faces += [(1, 2 + (i + 1) % 4, 2 + i) for i in range(4)]
        faces.sort(key=lambda face: sum(verts[v][2] for v in face))
        surface = pygame.Surface((128, 128), pygame.SRCALPHA)
        for face in faces:
            points = [(64 + verts[v][0] * 122, 64 + verts[v][1] * 122 + verts[v][2] * 20) for v in face]
            brightness = int(150 + 75 * (sum(verts[v][2] for v in face) + .55))
            brightness = min(250, brightness + (15 if face[0] == 0 else -30))
            pygame.draw.polygon(surface, (brightness,) * 3 + (255,), points)
            pygame.draw.polygon(surface, (245, 245, 245, 255), points, 1)
        gray = pygame.surfarray.array3d(surface)[:, :, 0].T.astype(np.float32)
        gray *= self.textures.diamond.astype(np.float32) / 230
        alpha = pygame.surfarray.array_alpha(surface).T
        self._diamond = (np.clip(gray, 0, 255).astype(np.uint8), alpha)
        return self._diamond

    def billboard(self, frame, depth_buffer, world, sprite, x, y, z, scale, horizon, glow=False):
        dx, dy = x - world.x, y - world.y
        c, s = math.cos(world.angle), math.sin(world.angle)
        depth = dx * c + dy * s
        if depth <= .1:
            return
        lateral = -dx * s + dy * c
        screen_x = self.width / 2 + lateral / depth * self.projection
        size = self.projection * scale / depth
        center_y = horizon + (.57 - z) * self.projection / depth
        left, top = screen_x - size / 2, center_y - size / 2
        x0, x1 = max(0, int(left)), min(self.width, int(left + size + 1))
        y0, y1 = max(0, int(top)), min(self.height, int(top + size + 1))
        if x0 >= x1 or y0 >= y1:
            return
        tx = np.clip(((np.arange(x0, x1) - left) / size * 128).astype(int), 0, 127)
        ty = np.clip(((np.arange(y0, y1) - top) / size * 128).astype(int), 0, 127)
        gray, alpha = sprite
        shade = max(.7, float(self.light(depth))) if glow else max(.36, float(self.light(depth)))
        src = gray[ty[:, None], tx[None, :]] * shade
        a = alpha[ty[:, None], tx[None, :]].astype(np.float32) / 255
        a *= (depth < depth_buffer[x0:x1])[None, :]
        region = frame[y0:y1, x0:x1]
        region[:] = region * (1 - a) + src * a

    def render(self, world, pitch=0, bob=0):
        distances, sides, material, tx, rx, ry = self.cast(world)
        horizon = self.height * .5 + pitch * self.height + bob
        delta = self.rows - horizon
        is_floor = delta >= 0
        plane_distance = np.where(is_floor, .57, .68) * self.projection / np.maximum(abs(delta), .5)
        plane_distance = np.minimum(plane_distance, 1000)
        wx, wy = world.x + plane_distance * rx[None, :], world.y + plane_distance * ry[None, :]
        px, py = (wx * 128).astype(np.int32) % 128, (wy * 128).astype(np.int32) % 128
        floor = self.textures.floor[py, px].astype(np.float32)
        ceiling = self.textures.ceiling[py, px].astype(np.float32)
        # Subtle floor joints provide motion and scale cues without introducing color.
        joints = (px < 2) | (py < 2)
        floor *= np.where(joints, .55, 1)
        ceiling *= .68
        frame = np.where(is_floor, floor, ceiling) * self.light(plane_distance)
        top = horizon - .68 * self.projection / distances
        wall_height = 1.25 * self.projection / distances
        wall_y = (self.rows - top[None, :]) / wall_height[None, :]
        mask = (wall_y >= 0) & (wall_y < 1)
        ty = np.clip((wall_y * 128).astype(np.int32), 0, 127)
        wall = self.textures.walls[material[None, :], ty, tx[None, :]].astype(np.float32)
        wall *= np.where(sides, .78, 1)[None, :] * self.light(distances)[None, :]
        wall *= np.where((wall_y > .94) | (wall_y < .045), .56, 1)
        frame[mask] = wall[mask]

        items = [(math.dist((world.x, world.y), world.goal), "diamond", None)]
        items += [(math.hypot(g.x - world.x, g.y - world.y), "ghost", g) for g in world.ghosts]
        for _, kind, ghost in sorted(items, key=lambda item: item[0], reverse=True):
            if kind == "diamond":
                self.billboard(frame, distances, world, self.diamond_sprite(world.time), *world.goal,
                               .66 + math.sin(world.time * 2.3) * .055, .66, horizon, True)
            else:
                self.billboard(frame, distances, world, self.ghost_sprite(ghost, world.time), ghost.x, ghost.y,
                               .38 + math.sin(world.time * 6 + ghost.phase) * .018, .78, horizon)
        frame *= self.vignette
        if world.damage_flash:
            frame += world.damage_flash * 85 * (1 - self.vignette) * 3
        gray = np.clip(frame, 0, 255).astype(np.uint8)
        pygame.surfarray.blit_array(self.surface, np.repeat(gray.T[:, :, None], 3, axis=2))
        return self.surface

    def rgb(self, world, pitch=0):
        """Optional pixel observation, H x W x 3, independent of the game HUD."""
        return pygame.surfarray.array3d(self.render(world, pitch)).transpose(1, 0, 2)
